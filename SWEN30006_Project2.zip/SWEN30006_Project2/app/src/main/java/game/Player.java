package game;

import ch.aplu.jcardgame.*;


public abstract class Player {
    protected Hand hand;
    protected int playerIndex;
    protected Deck deck;
    public Player(Hand hand, int playerIndex) {
        this.hand = hand;
        this.playerIndex = playerIndex;
    }

    public abstract Card play();
}

