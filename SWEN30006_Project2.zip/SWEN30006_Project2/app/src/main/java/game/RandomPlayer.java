package game;

import ch.aplu.jcardgame.*;
import java.util.Random;

public class RandomPlayer extends Player {
    private static final Random random = new Random();

    public RandomPlayer(Hand hand, int playerIndex) {
        super(hand, playerIndex);
    }

    @Override
    public Card play() {
        int x = random.nextInt(hand.getNumberOfCards());
        return hand.get(x);
    }
}