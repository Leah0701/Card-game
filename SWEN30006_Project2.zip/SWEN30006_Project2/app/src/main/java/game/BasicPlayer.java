package game;

import ch.aplu.jcardgame.*;
import java.util.List;

public class BasicPlayer extends Player {
    public BasicPlayer(Hand hand, int playerIndex) {
        super(hand, playerIndex);
    }

    @Override
    public Card play() {
        Card lowestCard = hand.get(0);
        for (Card card : hand.getCardList()) {
            if (compareCardValues(card, lowestCard) < 0) {
                lowestCard = card;
            }
        }
        return lowestCard;
    }

    private int compareCardValues(Card card1, Card card2) {
        Rank rank1 = (Rank) card1.getRank();
        Rank rank2 = (Rank) card2.getRank();
        Suit suit1 = (Suit) card1.getSuit();
        Suit suit2 = (Suit) card2.getSuit();

        int value1 = rank1.getScoreCardValue() * suit1.getMultiplicationFactor();
        int value2 = rank2.getScoreCardValue() * suit2.getMultiplicationFactor();

        return Integer.compare(value1, value2);
    }
}