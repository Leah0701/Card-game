package game;

import ch.aplu.jcardgame.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CleverPlayer extends Player {
    private final List<Card> playedCards = new ArrayList<>();
    private final Map<Suit, List<Rank>> suitToRanksMap = new HashMap<>();
    private final Hand playingArea;
    private final Deck deck;

    public CleverPlayer(Hand hand, int playerIndex, Hand playingArea, Deck deck) {
        super(hand, playerIndex);
        this.playingArea = playingArea;
        this.deck = deck;
        initSuitToRanksMap(); // Initialize suit to ranks mapping
    }

    private void initSuitToRanksMap() {
        for (Suit suit : Suit.values()) {
            suitToRanksMap.put(suit, new ArrayList<>());
        }
    }

    @Override
    public Card play() {
        updateSuitToRanksMap(); // Update the map with played cards
        Card bestCard = findBestCardToPlay(); // Find the best card to play
        hand.remove(bestCard, false); // Remove the selected card from hand
        return bestCard;
    }

    private void updateSuitToRanksMap() {
        for (Card card : playedCards) {
            Rank rank = (Rank) card.getRank();
            Suit suit = (Suit) card.getSuit();
            suitToRanksMap.get(suit).add(rank); // Track the rank of played cards
        }
    }

    private Card tryFormThirteen() {
        List<Card> publicCards = getPublicCards(); // Get public cards

        for (Card card1 : hand.getCardList()) {
            for (Card card2 : hand.getCardList()) {
                if (card1 != card2 && canFormThirteen(card1, card2)) {
                    return card1; // Return if two hand cards can form 13
                }
            }

            for (Card publicCard : publicCards) {
                if (canFormThirteen(card1, publicCard)) {
                    return card1; // Return if a hand card and a public card can form 13
                }
            }
        }

        // Check if two hand cards and two public cards can form 13
        if (hand.getNumberOfCards() >= 2 && publicCards.size() >= 2) {
            for (Card card1 : hand.getCardList()) {
                for (Card card2 : hand.getCardList()) {
                    if (card1 != card2) {
                        for (Card publicCard1 : publicCards) {
                            for (Card publicCard2 : publicCards) {
                                if (publicCard1 != publicCard2 && canFormThirteen(card1, card2, publicCard1, publicCard2)) {
                                    return card1; // Return if the combination forms 13
                                }
                            }
                        }
                    }
                }
            }
        }

        return null;
    }

    private Card findBestCardToPlay() {
        Card bestCard = tryFormThirteen();
        if (bestCard != null) {
            return bestCard; // Prioritize cards that form 13
        }

        bestCard = null;
        int bestCardValue = Integer.MIN_VALUE;
        for (Card card : hand.getCardList()) {
            int cardValue = calculateCardValue(card); // Calculate the card value
            if (cardValue > bestCardValue) {
                bestCard = card;
                bestCardValue = cardValue; // Select the card with the highest value
            }
        }
        return bestCard;
    }

    private int calculateCardValue(Card card) {
        Rank rank = (Rank) card.getRank();
        Suit suit = (Suit) card.getSuit();
        int baseValue = rank.getScoreCardValue() * suit.getMultiplicationFactor(); // Base value

        int remainingProbability = calculateRemainingProbability(card); // Probability of forming 13
        baseValue *= remainingProbability; // Adjust value based on probability

        return baseValue;
    }

    private int calculateRemainingProbability(Card card) {
        int count = 0;
        int totalPossible = 0;
        for (Suit suit : Suit.values()) {
            for (Rank rank : Rank.values()) {
                if (!suitToRanksMap.get(suit).contains(rank)) {
                    totalPossible++;
                    if (canFormThirteen(card, new Card(deck, suit, rank))) {
                        count++;
                    }
                }
            }
        }
        return (int) ((double) count / totalPossible * 100); // Calculate remaining probability
    }

    private boolean canFormThirteen(Card... cards) {
        int sum = 0;
        for (Card card : cards) {
            Rank rank = (Rank) card.getRank();
            int[] possibleValues = rank.getPossibleSumValues();
            sum += possibleValues[0]; // Sum possible values
        }
        return sum == 13;
    }

    public void trackPlayedCard(Card card) {
        playedCards.add(card); // Track played cards
    }

    public void updatePlayedCards(List<Card> cards) {
        playedCards.addAll(cards); // Update played cards
    }

    private List<Card> getPublicCards() {
        return playingArea.getCardList(); // Get the list of public cards
    }
}

