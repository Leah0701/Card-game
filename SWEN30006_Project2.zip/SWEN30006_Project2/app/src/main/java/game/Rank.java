package game;

public enum Rank {
    // Reverse order of rank importance (see rankGreater() below)
    ACE(1, 1, new int[]{0, 1}),
    KING(13, 13, new int[]{10, 11, 12, 13}),
    QUEEN(12, 12, new int[]{10, 11, 12, 13}),
    JACK(11, 11, new int[]{10, 11, 12, 13}),
    TEN(10, 10, new int[]{10}),
    NINE(9, 9, new int[]{9}),
    EIGHT(8, 8, new int[]{8}),
    SEVEN(7, 7, new int[]{7}),
    SIX(6, 6, new int[]{6}),
    FIVE(5, 5, new int[]{5}),
    FOUR(4, 4, new int[]{4}),
    THREE(3, 3, new int[]{3}),
    TWO(2, 2, new int[]{2});

    private final int rankCardValue;
    private final int scoreValue;
    private final int[] possibleSumValues;

    Rank(int rankCardValue, int scoreValue, int[] possibleSumValues) {
        this.rankCardValue = rankCardValue;
        this.scoreValue = scoreValue;
        this.possibleSumValues = possibleSumValues;
    }

    public int getRankCardValue() {
        return rankCardValue;
    }

    public int getScoreCardValue() {
        return scoreValue;
    }

    public int[] getPossibleSumValues() {
        return possibleSumValues;
    }

    public String getRankCardLog() {
        return String.format("%d", rankCardValue);
    }
}
