package game;

import ch.aplu.jcardgame.*;
import ch.aplu.jcardgame.Hand;
import ch.aplu.jcardgame.CardAdapter;
import ch.aplu.jcardgame.CardListener;
import java.util.concurrent.atomic.AtomicReference;

public class HumanPlayer extends Player {
    private AtomicReference<Card> selectedCard = new AtomicReference<>(null);

    public HumanPlayer(Hand hand, int playerIndex) {
        super(hand, playerIndex);
        initCardListener();
    }

    private void initCardListener() {
        hand.addCardListener(new CardAdapter() {
            @Override
            public void leftDoubleClicked(Card card) {
                selectedCard.set(card);
                synchronized (selectedCard) {
                    selectedCard.notifyAll();
                }
            }
        });
    }

    @Override
    public Card play() {
        selectedCard.set(null);
        hand.setTouchEnabled(true);

        synchronized (selectedCard) {
            while (selectedCard.get() == null) {
                try {
                    selectedCard.wait();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return null;
                }
            }
        }

        hand.setTouchEnabled(false);
        return selectedCard.get();
    }
}
