package game;

import ch.aplu.jcardgame.*;

public class PlayerFactory {
    private static PlayerFactory instance;

    private PlayerFactory() {

    }

    public static PlayerFactory getInstance() {
        if (instance == null) {
            instance = new PlayerFactory();
        }
        return instance;
    }

    public Player createPlayer(String type, Hand hand, int playerIndex, Hand playingArea, Deck deck) {
        switch (type) {
            case "human":
                return new HumanPlayer(hand, playerIndex);
            case "random":
                return new RandomPlayer(hand, playerIndex);
            case "basic":
                return new BasicPlayer(hand, playerIndex);
            case "clever":
                return new CleverPlayer(hand, playerIndex, playingArea, deck);
            default:
                throw new IllegalArgumentException("Unknown player type: " + type);
        }
    }
}